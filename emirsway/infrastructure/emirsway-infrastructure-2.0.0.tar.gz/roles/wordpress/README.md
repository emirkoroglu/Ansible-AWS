emirsway/wordpress
=========

Create wordpress site. You can try it on Ubuntu only.


Role Variables
--------------
wp_install_dir

wp_db_name

wp_db_user

wp_db_password

wp_db_host




Example Playbook
----------------

Including an example of how to use your role (for instance, with variables passed in as parameters) is always nice for users too:

    - hosts: servers
      roles:
         - { role: chanchal.wordpress }

License
-------
Check License.md


More about my work check below
-------
https://github.com/emirsway
https://galaxy.ansible.com/emirsway


Contact
-------
emirmails@gmail.com


License
-------
Check License.md
