chanchal/wordpress
=========

Create wordpress site. You can try it on CentOS7, Redhat7, Ubuntu or Debian


Role Variables
--------------
wp_install_dir

wp_db_name

wp_db_user

wp_db_password

wp_db_host




Example Playbook
----------------

Including an example of how to use your role (for instance, with variables passed in as parameters) is always nice for users too:

    - hosts: servers
      roles:
         - { role: chanchal.wordpress }

License
-------

BSD

Author Information
------------------
Maintainer: Chanchal Bose chanchal@mostlylinux.com
